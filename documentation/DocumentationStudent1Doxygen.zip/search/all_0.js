var searchData=
[
  ['assert_5fequal_0',['ASSERT_EQUAL',['../_test_student1_8c.html#a4eb2dea94d13f305ce42ea82cec4114b',1,'TestStudent1.c']]],
  ['assert_5ffalse_1',['ASSERT_FALSE',['../_test_student1_8c.html#a9efe2f02b4d8f1efc4b509bcc009df90',1,'TestStudent1.c']]],
  ['assert_5ftrue_2',['ASSERT_TRUE',['../_test_student1_8c.html#a1656b25134a180161dcd61a11184cd12',1,'TestStudent1.c']]]
];
