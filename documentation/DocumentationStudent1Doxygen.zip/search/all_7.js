var searchData=
[
  ['main_0',['main',['../_examples_student1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;ExamplesStudent1.c'],['../_test_student1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;TestStudent1.c']]],
  ['multisetpermutations_1',['MultisetPermutations',['../_student1_8c.html#ae22a6247f65d0f7490dae7b642f3b9fa',1,'MultisetPermutations(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c'],['../_student1_8h.html#ae22a6247f65d0f7490dae7b642f3b9fa',1,'MultisetPermutations(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c']]]
];
