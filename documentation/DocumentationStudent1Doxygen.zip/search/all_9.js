var searchData=
[
  ['permrecursivelexicographic_0',['PermRecursiveLexicographic',['../_student1_8c.html#a9d198954b3a3cbad6f0075fcc25188b8',1,'PermRecursiveLexicographic(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c'],['../_student1_8h.html#a9d198954b3a3cbad6f0075fcc25188b8',1,'PermRecursiveLexicographic(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c']]],
  ['permutationsbacktrack_1',['PermutationsBacktrack',['../_student1_8c.html#a58fd345fbccfee7ec7671f25da75dd62',1,'PermutationsBacktrack(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c'],['../_student1_8h.html#a58fd345fbccfee7ec7671f25da75dd62',1,'PermutationsBacktrack(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c']]],
  ['permutationsrecursiveswap_2',['PermutationsRecursiveSwap',['../_student1_8c.html#a5527f9a563514e3504cca504071ff70d',1,'PermutationsRecursiveSwap(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c'],['../_student1_8h.html#a5527f9a563514e3504cca504071ff70d',1,'PermutationsRecursiveSwap(int arr[], int n, void(*callback)(int perm[], int n)):&#160;Student1.c']]],
  ['permutationswithconstraints_3',['PermutationsWithConstraints',['../_student1_8c.html#a6e98a8f579fe5e5a916ab0271a1cf6d5',1,'PermutationsWithConstraints(int arr[], int n, bool(*constraint)(int partial[], int k, int nextElem, void *data), void *constraintData, void(*callback)(int perm[], int n)):&#160;Student1.c'],['../_student1_8h.html#a6e98a8f579fe5e5a916ab0271a1cf6d5',1,'PermutationsWithConstraints(int arr[], int n, bool(*constraint)(int partial[], int k, int nextElem, void *data), void *constraintData, void(*callback)(int perm[], int n)):&#160;Student1.c']]],
  ['posconstraint_4',['PosConstraint',['../_student1_8h.html#aff292465f1fbc7980faee0c0cb857e4c',1,'Student1.h']]],
  ['posconstraints_5',['posConstraints',['../struct_constraint_data.html#a40920129b599986a6d44cd99db0c6f01',1,'ConstraintData']]],
  ['position_6',['position',['../struct_position_constraint.html#afec4108d18320c0e46e1ccdc294f1865',1,'PositionConstraint']]],
  ['positionconstraint_7',['PositionConstraint',['../struct_position_constraint.html',1,'']]],
  ['printpermutation_8',['PrintPermutation',['../_examples_student1_8c.html#a07f73f8eb19c5da30d32a24cc07aa6b9',1,'ExamplesStudent1.c']]]
];
