var searchData=
[
  ['savetocache_0',['SaveToCache',['../_student1_8c.html#a73f211445c711e5fe27b11187468387a',1,'SaveToCache(char *key, long value):&#160;Student1.c'],['../_student1_8h.html#a73f211445c711e5fe27b11187468387a',1,'SaveToCache(char *key, long value):&#160;Student1.c']]],
  ['swap_1',['Swap',['../_student1_8c.html#ad46076d2560def8d035f09bca7cbee91',1,'Swap(int *a, int *b):&#160;Student1.c'],['../_student1_8h.html#ad46076d2560def8d035f09bca7cbee91',1,'Swap(int *a, int *b):&#160;Student1.c']]]
];
