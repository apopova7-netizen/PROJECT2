var searchData=
[
  ['student1_2ec_0',['Student1.c',['../_student1_8c.html',1,'']]],
  ['student1_2eh_1',['Student1.h',['../_student1_8h.html',1,'']]]
];
