var searchData=
[
  ['factorial_0',['Factorial',['../_student1_8c.html#ae791c3ce31422876d51a1ac25732d33e',1,'Factorial(long n):&#160;Student1.c'],['../_student1_8h.html#ae791c3ce31422876d51a1ac25732d33e',1,'Factorial(long n):&#160;Student1.c']]],
  ['findincache_1',['FindInCache',['../_student1_8c.html#ac450983723b2e01061b04457115fe77e',1,'FindInCache(char *key):&#160;Student1.c'],['../_student1_8h.html#ac450983723b2e01061b04457115fe77e',1,'FindInCache(char *key):&#160;Student1.c']]]
];
