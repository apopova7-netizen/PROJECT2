var searchData=
[
  ['cache_0',['cache',['../_student1_8c.html#a2d3675bbc9dd38b4c101f0a55d499a0e',1,'Student1.c']]],
  ['cachesize_1',['cacheSize',['../_student1_8c.html#a21f5d4e833c67e26ce27afd3d9f23288',1,'Student1.c']]],
  ['callbackcount_2',['callbackCount',['../_test_student1_8c.html#af01579fbb11f59ae8b979b1dcd12951e',1,'TestStudent1.c']]]
];
