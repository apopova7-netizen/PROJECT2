var searchData=
[
  ['quicksort_0',['QuickSort',['../_student1_8c.html#aeb2a770140582a4f41360218b380fed8',1,'QuickSort(int arr[], int left, int right):&#160;Student1.c'],['../_student1_8h.html#aeb2a770140582a4f41360218b380fed8',1,'QuickSort(int arr[], int left, int right):&#160;Student1.c']]]
];
