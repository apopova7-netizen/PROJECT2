var searchData=
[
  ['g_5fcounta_0',['g_countA',['../_examples_student1_8c.html#a7dbd220d8df95b01c3ee08f7d4096d34',1,'ExamplesStudent1.c']]],
  ['g_5fcountb_1',['g_countB',['../_examples_student1_8c.html#a549b534a0557933da14fc242a33ab3b0',1,'ExamplesStudent1.c']]]
];
