var struct_cache_elem =
[
    [ "key", "struct_cache_elem.html#a796ba21867d6c71513f4e7160b27573d", null ],
    [ "value", "struct_cache_elem.html#ac41d99e71664b33dbab3def9612cdeb3", null ]
];