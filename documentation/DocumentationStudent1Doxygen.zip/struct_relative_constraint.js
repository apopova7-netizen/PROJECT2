var struct_relative_constraint =
[
    [ "elemA", "struct_relative_constraint.html#a1f497bf22ba604531bf090427ed2a1be", null ],
    [ "elemB", "struct_relative_constraint.html#addafa34d4e2223a520850e6df6ea43d7", null ]
];