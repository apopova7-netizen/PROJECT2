var _examples_student1_8c =
[
    [ "Constraint", "_examples_student1_8c.html#a79a0d61b255795bf846839e037cba3a5", null ],
    [ "CountOnly", "_examples_student1_8c.html#ab428e7ce126a9845c1620b9ae93bed08", null ],
    [ "LimitedPrint7", "_examples_student1_8c.html#a33ae46983862cfdd8b301a063dd26993", null ],
    [ "main", "_examples_student1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4", null ],
    [ "PrintPermutation", "_examples_student1_8c.html#a07f73f8eb19c5da30d32a24cc07aa6b9", null ],
    [ "g_countA", "_examples_student1_8c.html#a7dbd220d8df95b01c3ee08f7d4096d34", null ],
    [ "g_countB", "_examples_student1_8c.html#a549b534a0557933da14fc242a33ab3b0", null ]
];