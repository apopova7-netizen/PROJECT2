var struct_constraint_data =
[
    [ "numPosConstraints", "struct_constraint_data.html#a169c0c2d24a30d7a1524192ce99f9a7a", null ],
    [ "numRelConstraints", "struct_constraint_data.html#a75f5379b0d5c2a58e40d0f5050649aeb", null ],
    [ "posConstraints", "struct_constraint_data.html#a40920129b599986a6d44cd99db0c6f01", null ],
    [ "relConstraints", "struct_constraint_data.html#ab0258c1f479841bc86314543ba70542a", null ]
];