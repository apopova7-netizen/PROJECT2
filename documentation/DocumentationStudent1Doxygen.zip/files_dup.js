var files_dup =
[
    [ "ExamplesStudent1.c", "_examples_student1_8c.html", "_examples_student1_8c" ],
    [ "Student1.c", "_student1_8c.html", "_student1_8c" ],
    [ "Student1.h", "_student1_8h.html", "_student1_8h" ],
    [ "TestStudent1.c", "_test_student1_8c.html", "_test_student1_8c" ]
];